/**
* user: admin
* pass: 5TK174F5JeyoxF5U6A0PJo76oL5X7oXW
*/
insert into users (username, passwd, user_role) values ('admin', '$2a$10$fVXB3ZA4Qs/ckKeX.Bssge1qQ4/FXSR2yxV2rDejKG1Uuar/hqJH.', 0);